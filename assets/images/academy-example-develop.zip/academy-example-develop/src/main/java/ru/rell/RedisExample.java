package ru.rell;

import redis.clients.jedis.Jedis;

public class RedisExample {
    public static void main(String[] args) {
        try (Jedis jedis = new Jedis("localhost", 6379)) {
            jedis.auth("redis123");
            
            // String
            jedis.set("user:1:name", "Bob");
            String name = jedis.get("user:1:name");
            System.out.println("✅ Redis (String): user:1:name = " + name);
            
            // Hash
            jedis.hset("user:2", "name", "Charlie");
            jedis.hset("user:2", "age", "30");
            System.out.println("✅ Redis (Hash): " + jedis.hgetAll("user:2"));
            
            // List (очередь)
            jedis.lpush("tasks", "task1", "task2");
            String task = jedis.rpop("tasks");
            System.out.println("✅ Redis (Queue): Извлечена задача - " + task);
            
            // Установка TTL
            jedis.setex("temp_key", 10, "я умру через 10 секунд");
            System.out.println("⏰ Redis: Установлен TTL 10 сек");
        }
    }
}