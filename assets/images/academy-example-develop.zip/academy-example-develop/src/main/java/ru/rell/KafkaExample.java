package ru.rell;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

public class KafkaExample {
    private static final String BOOTSTRAP_SERVERS = "localhost:9092";
    private static final String TOPIC = "demo-topic";
    
    public static void main(String[] args) throws InterruptedException {
        // Создаём топик (если не существует)
        createTopic();
        
        // Producer в отдельном потоке
        Thread producerThread = new Thread(() -> produceMessages());
        producerThread.start();
        
        // Consumer в отдельном потоке
        Thread consumerThread = new Thread(() -> consumeMessages());
        consumerThread.start();
        
        Thread.sleep(5000); // Даем поработать 5 секунд
        System.exit(0);
    }
    
    private static void createTopic() {
        Properties props = new Properties();
        props.put("bootstrap.servers", BOOTSTRAP_SERVERS);
        
        try (AdminClient admin = AdminClient.create(props)) {
            NewTopic newTopic = new NewTopic(TOPIC, 1, (short) 1);
            admin.createTopics(List.of(newTopic));
            System.out.println("✅ Kafka: Топик создан - " + TOPIC);
        } catch (Exception e) {
            System.out.println("ℹ️ Kafka: Топик уже существует");
        }
    }
    
    private static void produceMessages() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        
        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= 5; i++) {
                String key = "key-" + i;
                String value = "Message " + i + " at " + System.currentTimeMillis();
                
                ProducerRecord<String, String> record = new ProducerRecord<>(TOPIC, key, value);
                producer.send(record, (metadata, exception) -> {
                    if (exception == null) {
                        System.out.printf("✅ Kafka: Отправлено - ключ='%s', значение='%s', partition=%d, offset=%d%n",
                            key, value, metadata.partition(), metadata.offset());
                    } else {
                        System.err.println("❌ Kafka ошибка: " + exception.getMessage());
                    }
                });
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private static void consumeMessages() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "demo-group-" + UUID.randomUUID());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        
        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(List.of(TOPIC));
            
            while (true) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
                records.forEach(record -> {
                    System.out.printf("📨 Kafka: Получено - ключ='%s', значение='%s', partition=%d, offset=%d%n",
                        record.key(), record.value(), record.partition(), record.offset());
                });
                if (!records.isEmpty()) break;
            }
        }
    }
}