package ru.rell;

import com.rabbitmq.client.*;

public class RabbitMQExample {
    private static final String QUEUE_NAME = "task_queue";
    private static final String EXCHANGE_NAME = "logs";
    
    public static void main(String[] args) throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        factory.setPort(5672);
        factory.setUsername("guest");
        factory.setPassword("guest");
        
        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {
            
            // 1. Простая очередь
            channel.queueDeclare(QUEUE_NAME, true, false, false, null);
            String message = "Hello RabbitMQ!";
            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
            System.out.println("✅ RabbitMQ: Отправлено в очередь - '" + message + "'");
            
            // 2. Pub/Sub с Exchange
            channel.exchangeDeclare(EXCHANGE_NAME, "fanout");
            String queueName = channel.queueDeclare().getQueue();
            channel.queueBind(queueName, EXCHANGE_NAME, "");
            
            // Публикация
            String broadcastMsg = "Broadcast message to all subscribers";
            channel.basicPublish(EXCHANGE_NAME, "", null, broadcastMsg.getBytes());
            System.out.println("✅ RabbitMQ: Опубликовано в exchange - '" + broadcastMsg + "'");
            
            // Подписка (в отдельном потоке)
            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String received = new String(delivery.getBody());
                System.out.println("📨 RabbitMQ: Получено - '" + received + "'");
            };
            channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {});
            
            Thread.sleep(1000); // Даем время получить сообщение
        }
    }
}