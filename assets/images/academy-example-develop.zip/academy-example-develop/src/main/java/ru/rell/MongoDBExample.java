package ru.rell;

import com.mongodb.client.*;
import org.bson.Document;

public class MongoDBExample {
    private static final String CONNECTION_STRING = "mongodb://admin:admin123@localhost:27017";
    private static final String DATABASE = "appdb";
    
    public static void main(String[] args) {
        try (MongoClient client = MongoClients.create(CONNECTION_STRING)) {
            MongoCollection<Document> collection = client.getDatabase(DATABASE)
                .getCollection("users");
            
            // Вставка
            Document user = new Document("name", "Alice")
                .append("email", "alice@example.com")
                .append("age", 25);
            collection.insertOne(user);
            System.out.println("✅ MongoDB: Документ добавлен");
            
            // Чтение
            Document found = collection.find(new Document("name", "Alice")).first();
            System.out.println("📖 MongoDB: Найден - " + found.toJson());
        }
    }
}