

docker-compose up -d

# Проверка статуса
docker-compose ps

# Просмотр логов
docker-compose logs -f


# MongoDB
docker exec -it mongodb-demo mongosh -u admin -p admin123 --authenticationDatabase admin

# Redis
docker exec -it redis-demo redis-cli -a redis123

# RabbitMQ (открыть в браузере)
open http://localhost:15672  # guest/guest

# Kafka UI
open http://localhost:8080


# Сборка
mvn clean compile

# Запуск по отдельности
mvn exec:java -Dexec.mainClass="com.demo.mongodb.MongoDBExample"
mvn exec:java -Dexec.mainClass="com.demo.redis.RedisExample"
mvn exec:java -Dexec.mainClass="com.demo.rabbitmq.RabbitMQExample"
mvn exec:java -Dexec.mainClass="com.demo.kafka.KafkaExample"


# Остановить все сервисы
docker-compose down

# Остановить с удалением томов (очистка данных)
docker-compose down -v