package ru.rell;

import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import org.bson.Document;

public class MongoDBDemo {
    
    // Конфигурация подключения
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "university";
    private static final String COLLECTION_NAME = "students";
    
    public static void main(String[] args) {
        
        // 1. Подключение к MongoDB
        try (MongoClient mongoClient = MongoClients.create(CONNECTION_STRING)) {
            
            System.out.println("✅ Подключение к MongoDB установлено!");
            
            // 2. Получаем базу данных и коллекцию
            MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
            MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
            
            // 3. Демонстрация CRUD операций
            
            // CREATE - Добавление студентов
            System.out.println("\n📝 CREATE: Добавляем студентов...");
            addStudents(collection);
            
            // READ - Чтение всех студентов
            System.out.println("\n📖 READ: Список всех студентов:");
            readAllStudents(collection);
            
            // READ с фильтром - Поиск по возрасту
            System.out.println("\n🔍 READ: Студенты старше 20 лет:");
            readStudentsOlderThan(collection, 20);
            
            // UPDATE - Обновление информации
            System.out.println("\n✏️ UPDATE: Обновляем курс студента...");
            updateStudentCourse(collection, "Иван Петров", 3);
            
            // DELETE - Удаление студента
            System.out.println("\n🗑️ DELETE: Удаляем студента...");
            deleteStudent(collection, "Сидоров");
            
            // Финальный вывод
            System.out.println("\n📊 ИТОГО: Оставшиеся студенты:");
            readAllStudents(collection);
            
        } catch (Exception e) {
            System.err.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // CREATE - Добавление студентов
    private static void addStudents(MongoCollection<Document> collection) {
        Document student1 = new Document("name", "Иван Петров")
                .append("age", 20)
                .append("course", 2)
                .append("faculty", "Информатика");
        
        Document student2 = new Document("name", "Мария Сидорова")
                .append("age", 19)
                .append("course", 1)
                .append("faculty", "Математика");
        
        Document student3 = new Document("name", "Алексей Смирнов")
                .append("age", 22)
                .append("course", 4)
                .append("faculty", "Физика");
        
        collection.insertMany(java.util.Arrays.asList(student1, student2, student3));
        System.out.println("✅ Добавлено 3 студента");
    }
    
    // READ - Чтение всех студентов
    private static void readAllStudents(MongoCollection<Document> collection) {
        FindIterable<Document> students = collection.find();
        for (Document student : students) {
            printStudent(student);
        }
    }
    
    // READ с фильтром - студенты старше указанного возраста
    private static void readStudentsOlderThan(MongoCollection<Document> collection, int age) {
        FindIterable<Document> students = collection.find(Filters.gt("age", age));
        for (Document student : students) {
            printStudent(student);
        }
    }
    
    // UPDATE - Обновление курса студента
    private static void updateStudentCourse(MongoCollection<Document> collection, String name, int newCourse) {
        collection.updateOne(
            Filters.eq("name", name),
            new Document("$set", new Document("course", newCourse))
        );
        System.out.println("✅ Студенту " + name + " изменён курс на " + newCourse);
    }
    
    // DELETE - Удаление студента по имени
    private static void deleteStudent(MongoCollection<Document> collection, String namePart) {
        long deletedCount = collection.deleteMany(Filters.regex("name", namePart)).getDeletedCount();
        System.out.println("✅ Удалено студентов: " + deletedCount);
    }
    
    // Вспомогательный метод для вывода студента
    private static void printStudent(Document student) {
        System.out.printf("  • %s, %d лет, %d курс, факультет: %s%n",
            student.getString("name"),
            student.getInteger("age"),
            student.getInteger("course"),
            student.getString("faculty")
        );
    }
}